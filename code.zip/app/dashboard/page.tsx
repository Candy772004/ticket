"use client"

import { useAuth } from "@/components/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { TicketForm } from "@/components/ticket-form"
import { TicketList } from "@/components/ticket-list"
import type { Ticket } from "@/lib/tickets"
import { Button } from "@/components/ui/button"
import { SyncStatusIndicator } from "@/components/sync-status-indicator"
import { NotificationCenter } from "@/components/notification-center"
import useSWR, { mutate } from "swr"
import { useRealTimeSync } from "@/hooks/use-real-time-sync"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export default function Dashboard() {
  const { user, loading, logout } = useAuth()
  const router = useRouter()
  const [isCreating, setIsCreating] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const { data: tickets = [] } = useSWR<Ticket[]>("/api/tickets", fetcher)

  const { startSync } = useRealTimeSync("/api/tickets", {
    interval: 5000,
    onDataChange: (newData, oldData) => {
      mutate("/api/tickets", newData, false)
      const newTickets = newData.filter((t: any) => !oldData.some((o: any) => o.id === t.id))
      if (newTickets.length > 0) {
        setNotifications((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            title: "New Tickets",
            message: `${newTickets.length} new ticket(s) received`,
            type: "info",
            timestamp: new Date(),
          },
        ])
      }
    },
  })

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    } else if (!loading && user) {
      startSync()
    }
  }, [loading, user, router, startSync])

  const handleLogout = async () => {
    await logout()
    router.push("/login")
  }

  const handleCreateTicket = async (data: { title: string; description: string; priority: string }) => {
    setIsCreating(true)
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (res.ok) {
        mutate("/api/tickets")
        setNotifications((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            title: "Ticket Created",
            message: "Your support ticket has been created successfully",
            type: "success",
            timestamp: new Date(),
          },
        ])
      }
    } finally {
      setIsCreating(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <p className="text-foreground">Loading...</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">TicketHub Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome, {user?.name}!</p>
          </div>
          <div className="flex items-center gap-4">
            <SyncStatusIndicator />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative"
            >
              🔔
              {notifications.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {notifications.length}
                </span>
              )}
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-1">
            <TicketForm onSubmit={handleCreateTicket} isLoading={isCreating} />
          </div>
          <div className="md:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Your Tickets</h2>
            <TicketList tickets={tickets} />
          </div>
        </div>
      </div>

      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
        onClear={() => setNotifications([])}
      />
    </main>
  )
}
