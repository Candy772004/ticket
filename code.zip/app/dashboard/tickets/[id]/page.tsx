"use client"

import type React from "react"

import { useAuth } from "@/components/auth-context"
import { useRouter, useParams } from "next/navigation"
import { useEffect, useState } from "react"
import type { Ticket } from "@/lib/tickets"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

const statusColors: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-700 dark:text-blue-300",
  "in-progress": "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300",
  resolved: "bg-green-500/20 text-green-700 dark:text-green-300",
  closed: "bg-gray-500/20 text-gray-700 dark:text-gray-300",
}

const priorityColors: Record<string, string> = {
  low: "bg-green-500/10 text-green-700 dark:text-green-300",
  medium: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  high: "bg-orange-500/10 text-orange-700 dark:text-orange-300",
  urgent: "bg-red-500/10 text-red-700 dark:text-red-300",
}

export default function TicketDetail() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const params = useParams()
  const id = params?.id as string

  const { data: ticket } = useSWR<Ticket>(id ? `/api/tickets/${id}` : null, fetcher)
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [newStatus, setNewStatus] = useState<string>("")

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  useEffect(() => {
    if (ticket) {
      setNewStatus(ticket.status)
    }
  }, [ticket])

  if (!ticket) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Loading ticket...</p>
      </div>
    )
  }

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const res = await fetch(`/api/tickets/${id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: comment }),
      })

      if (res.ok) {
        setComment("")
        // Refetch ticket to show new comment
        const updated = await fetch(`/api/tickets/${id}`).then((r) => r.json())
        // In production, use SWR mutation here
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleStatusChange = async (newSt: string) => {
    setNewStatus(newSt)
    await fetch(`/api/tickets/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newSt }),
    })
  }

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => router.push("/dashboard")} className="mb-4">
            ← Back to Dashboard
          </Button>
          <h1 className="text-2xl font-bold">{ticket.title}</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            {/* Ticket Details */}
            <Card>
              <CardHeader>
                <CardTitle>Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Description</label>
                  <p className="mt-2">{ticket.description}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Ticket ID</label>
                  <p className="mt-2 font-mono text-sm">{ticket.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Created</label>
                  <p className="mt-2">{new Date(ticket.createdAt).toLocaleString()}</p>
                </div>
              </CardContent>
            </Card>

            {/* Comments */}
            <Card>
              <CardHeader>
                <CardTitle>Comments</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ticket.comments.length === 0 ? (
                  <p className="text-muted-foreground">No comments yet</p>
                ) : (
                  <div className="space-y-4">
                    {ticket.comments.map((c) => (
                      <div key={c.id} className="border-l-2 border-muted pl-4 py-2">
                        <p className="text-sm">{c.content}</p>
                        <p className="text-xs text-muted-foreground mt-1">{new Date(c.createdAt).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                )}

                <form onSubmit={handleAddComment} className="space-y-3 mt-4 pt-4 border-t border-border">
                  <textarea
                    className="w-full rounded-md border border-input bg-input px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Add a comment..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={3}
                  />
                  <Button type="submit" disabled={isSubmitting || !comment}>
                    {isSubmitting ? "Adding..." : "Add Comment"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Status</CardTitle>
              </CardHeader>
              <CardContent>
                <Select value={newStatus} onValueChange={handleStatusChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <div className="mt-3">
                  <Badge className={statusColors[newStatus]}>{newStatus}</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Priority</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className={priorityColors[ticket.priority]}>{ticket.priority}</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
