import { getTicket, updateTicket } from "@/lib/tickets"
import { isUserAdmin } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = request.cookies.get("session")?.value
  if (!session || !isUserAdmin(session)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const { id } = await params
  const { assignedTo } = await request.json()

  const ticket = getTicket(id)
  if (!ticket) {
    return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
  }

  const updated = updateTicket(id, { assignedTo })
  return NextResponse.json(updated)
}
