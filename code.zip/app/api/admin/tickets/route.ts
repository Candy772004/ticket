import { getAllTickets } from "@/lib/tickets"
import { isUserAdmin } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const session = request.cookies.get("session")?.value
  if (!session || !isUserAdmin(session)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const tickets = getAllTickets()
  return NextResponse.json(tickets)
}
