import { isUserAdmin, updateUserRole } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function PATCH(request: Request, { params }: { params: Promise<{ email: string }> }) {
  const session = request.cookies.get("session")?.value
  if (!session || !isUserAdmin(session)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const { email } = await params
  const { role } = await request.json()

  if (!["user", "admin"].includes(role)) {
    return NextResponse.json({ error: "Invalid role" }, { status: 400 })
  }

  const success = updateUserRole(email, role)
  if (!success) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  return NextResponse.json({ success: true })
}
