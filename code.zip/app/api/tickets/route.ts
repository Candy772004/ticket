import { createTicket, getAllTickets, getUserTickets } from "@/lib/tickets"
import { validateSession } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const session = request.cookies.get("session")?.value
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const user = validateSession(session)
  if (!user) {
    return NextResponse.json({ error: "Invalid session" }, { status: 401 })
  }

  const tickets = user.role === "admin" ? getAllTickets() : getUserTickets(user.id)
  return NextResponse.json(tickets)
}

export async function POST(request: Request) {
  const session = request.cookies.get("session")?.value
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const user = validateSession(session)
  if (!user) {
    return NextResponse.json({ error: "Invalid session" }, { status: 401 })
  }

  try {
    const { title, description, priority } = await request.json()
    const ticket = createTicket(title, description, user.id, priority)
    return NextResponse.json(ticket)
  } catch (error) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}
