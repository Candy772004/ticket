import { getTicket, addComment } from "@/lib/tickets"
import { validateSession } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = request.cookies.get("session")?.value
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const user = validateSession(session)
  if (!user) {
    return NextResponse.json({ error: "Invalid session" }, { status: 401 })
  }

  const { id } = await params
  const ticket = getTicket(id)

  if (!ticket) {
    return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
  }

  if (ticket.userId !== user.id && user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  try {
    const { content } = await request.json()
    const comment = addComment(id, content, user.id)
    return NextResponse.json(comment)
  } catch (error) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}
