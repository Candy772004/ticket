import { validateSession } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const session = request.cookies.get("session")?.value
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const user = validateSession(session)
  if (!user) {
    return NextResponse.json({ error: "Invalid session" }, { status: 401 })
  }

  return NextResponse.json(user)
}
