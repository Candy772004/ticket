import { registerUser, loginUser } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 })
    }

    const user = registerUser(email, password, name)
    if (!user) {
      return NextResponse.json({ error: "User already exists" }, { status: 409 })
    }

    const sessionId = loginUser(email, password)
    const response = NextResponse.json({ user })
    response.cookies.set("session", sessionId || "", { httpOnly: true, maxAge: 7 * 24 * 60 * 60 })

    return response
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
