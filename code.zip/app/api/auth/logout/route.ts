import { logoutSession } from "@/lib/auth"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  const session = request.cookies.get("session")?.value
  if (session) {
    logoutSession(session)
  }

  const response = NextResponse.json({ success: true })
  response.cookies.set("session", "", { maxAge: 0 })
  return response
}
