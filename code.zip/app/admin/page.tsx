"use client"

import { useAuth } from "@/components/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { AdminStats } from "@/components/admin-stats"
import { AdminTicketsTable } from "@/components/admin-tickets-table"
import { UsersManagement } from "@/components/users-management"
import { SyncStatusIndicator } from "@/components/sync-status-indicator"
import { NotificationCenter } from "@/components/notification-center"
import type { Ticket } from "@/lib/tickets"
import useSWR, { mutate } from "swr"
import { useRealTimeSync } from "@/hooks/use-real-time-sync"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

interface User {
  id: string
  email: string
  name: string
  role: "user" | "admin"
}

export default function AdminDashboard() {
  const { user, loading, logout } = useAuth()
  const router = useRouter()
  const { data: tickets = [] } = useSWR<Ticket[]>("/api/admin/tickets", fetcher)
  const { data: users = [] } = useSWR<User[]>("/api/admin/users", fetcher)
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])

  const { startSync } = useRealTimeSync("/api/admin/tickets", {
    interval: 3000,
    onDataChange: (newData, oldData) => {
      mutate("/api/admin/tickets", newData, false)
      const urgentTickets = newData.filter((t: any) => t.priority === "urgent")
      if (urgentTickets.length > oldData.filter((t: any) => t.priority === "urgent").length) {
        setNotifications((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            title: "Urgent Ticket Alert",
            message: "New urgent tickets require immediate attention",
            type: "error",
            timestamp: new Date(),
          },
        ])
      }
    },
  })

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      router.push("/dashboard")
    } else if (!loading && user) {
      startSync()
    }
  }, [loading, user, router, startSync])

  const handleLogout = async () => {
    await logout()
    router.push("/login")
  }

  const handleStatusChange = async (ticketId: string, status: string) => {
    await fetch(`/api/tickets/${ticketId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    })
    mutate("/api/admin/tickets")
  }

  const handleRoleChange = async (email: string, role: "user" | "admin") => {
    await fetch(`/api/admin/users/${email}/role`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role }),
    })
    mutate("/api/admin/users")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <p className="text-foreground">Loading...</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground">System Management</p>
          </div>
          <div className="flex items-center gap-4">
            <SyncStatusIndicator />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative"
            >
              🔔
              {notifications.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {notifications.length}
                </span>
              )}
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-8">
          <AdminStats tickets={tickets} />

          <Tabs defaultValue="tickets" className="space-y-4">
            <TabsList>
              <TabsTrigger value="tickets">All Tickets</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
            </TabsList>

            <TabsContent value="tickets" className="space-y-4">
              <AdminTicketsTable tickets={tickets} onStatusChange={handleStatusChange} onAssign={async () => {}} />
            </TabsContent>

            <TabsContent value="users" className="space-y-4">
              <UsersManagement users={users} onRoleChange={handleRoleChange} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
        onClear={() => setNotifications([])}
      />
    </main>
  )
}
