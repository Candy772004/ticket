"use client"

import { useAuth } from "@/components/auth-context"
import { useRouter, useParams } from "next/navigation"
import { useEffect, useState } from "react"
import type { Ticket } from "@/lib/tickets"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

const statusColors: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-700 dark:text-blue-300",
  "in-progress": "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300",
  resolved: "bg-green-500/20 text-green-700 dark:text-green-300",
  closed: "bg-gray-500/20 text-gray-700 dark:text-gray-300",
}

const priorityColors: Record<string, string> = {
  low: "bg-green-500/10 text-green-700 dark:text-green-300",
  medium: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  high: "bg-orange-500/10 text-orange-700 dark:text-orange-300",
  urgent: "bg-red-500/10 text-red-700 dark:text-red-300",
}

export default function AdminTicketDetail() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const params = useParams()
  const id = params?.id as string

  const { data: ticket } = useSWR<Ticket>(id ? `/api/tickets/${id}` : null, fetcher)
  const [newStatus, setNewStatus] = useState<string>("")

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      router.push("/dashboard")
    }
  }, [loading, user, router])

  useEffect(() => {
    if (ticket) {
      setNewStatus(ticket.status)
    }
  }, [ticket])

  if (!ticket) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Loading ticket...</p>
      </div>
    )
  }

  const handleStatusChange = async (status: string) => {
    setNewStatus(status)
    await fetch(`/api/tickets/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    })
  }

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => router.push("/admin")} className="mb-4">
            ← Back to Admin
          </Button>
          <h1 className="text-2xl font-bold">{ticket.title}</h1>
          <p className="text-sm text-muted-foreground mt-1">From: {ticket.userId}</p>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Ticket Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Description</label>
                  <p className="mt-2">{ticket.description}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Ticket ID</label>
                  <p className="mt-2 font-mono text-sm">{ticket.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Created</label>
                  <p className="mt-2">{new Date(ticket.createdAt).toLocaleString()}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Comments ({ticket.comments.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {ticket.comments.length === 0 ? (
                  <p className="text-muted-foreground">No comments yet</p>
                ) : (
                  <div className="space-y-4">
                    {ticket.comments.map((c) => (
                      <div key={c.id} className="border-l-2 border-muted pl-4 py-2">
                        <p className="text-sm">{c.content}</p>
                        <p className="text-xs text-muted-foreground mt-1">{new Date(c.createdAt).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Select value={newStatus} onValueChange={handleStatusChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Badge className={statusColors[newStatus]}>{newStatus}</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Priority</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className={priorityColors[ticket.priority]}>{ticket.priority}</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
