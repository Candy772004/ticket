"use client"

import { useCallback, useRef } from "react"
import { useToast } from "@/hooks/use-toast"

interface Notification {
  id: string
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
  timestamp: Date
}

export function useNotifications() {
  const { toast } = useToast()
  const notificationsRef = useRef<Notification[]>([])
  const lastCheckRef = useRef<number>(Date.now())

  const addNotification = useCallback(
    (notification: Omit<Notification, "id" | "timestamp">) => {
      const newNotification: Notification = {
        ...notification,
        id: Math.random().toString(36).substring(7),
        timestamp: new Date(),
      }

      notificationsRef.current.push(newNotification)

      // Show toast
      toast({
        title: notification.title,
        description: notification.message,
        variant: notification.type === "error" ? "destructive" : "default",
      })

      return newNotification
    },
    [toast],
  )

  const getNotifications = useCallback(() => {
    return notificationsRef.current
  }, [])

  const clearNotifications = useCallback(() => {
    notificationsRef.current = []
  }, [])

  return {
    addNotification,
    getNotifications,
    clearNotifications,
  }
}
