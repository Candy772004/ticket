"use client"

import { useEffect, useRef, useCallback } from "react"
import { useNotifications } from "./use-notifications"

interface SyncOptions {
  interval?: number
  onDataChange?: (newData: any, oldData: any) => void
}

export function useRealTimeSync(url: string, options: SyncOptions = { interval: 5000 }) {
  const { addNotification } = useNotifications()
  const intervalRef = useRef<NodeJS.Timeout>()
  const lastDataRef = useRef<any>(null)

  const startSync = useCallback(() => {
    const sync = async () => {
      try {
        const response = await fetch(url)
        if (!response.ok) return

        const newData = await response.json()

        // Detect changes
        if (lastDataRef.current && JSON.stringify(lastDataRef.current) !== JSON.stringify(newData)) {
          if (options.onDataChange) {
            options.onDataChange(newData, lastDataRef.current)
          }

          // Notify about updates
          addNotification({
            title: "Data Updated",
            message: "Ticket information has been updated",
            type: "info",
          })
        }

        lastDataRef.current = newData
      } catch (error) {
        console.error("Sync error:", error)
      }
    }

    // Initial sync
    sync()

    // Set up interval
    if (options.interval) {
      intervalRef.current = setInterval(sync, options.interval)
    }
  }, [url, options, addNotification])

  const stopSync = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }
  }, [])

  useEffect(() => {
    return () => stopSync()
  }, [stopSync])

  return { startSync, stopSync }
}
