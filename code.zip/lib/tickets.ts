import crypto from "crypto"

export interface Ticket {
  id: string
  title: string
  description: string
  status: "open" | "in-progress" | "resolved" | "closed"
  priority: "low" | "medium" | "high" | "urgent"
  userId: string
  assignedTo?: string
  createdAt: Date
  updatedAt: Date
  comments: Comment[]
}

export interface Comment {
  id: string
  content: string
  userId: string
  createdAt: Date
}

// In-memory ticket storage
const tickets: Map<string, Ticket> = new Map()

export function createTicket(
  title: string,
  description: string,
  userId: string,
  priority: "low" | "medium" | "high" | "urgent" = "medium",
): Ticket {
  const id = crypto.randomUUID()
  const ticket: Ticket = {
    id,
    title,
    description,
    status: "open",
    priority,
    userId,
    createdAt: new Date(),
    updatedAt: new Date(),
    comments: [],
  }
  tickets.set(id, ticket)
  return ticket
}

export function getTicket(id: string): Ticket | null {
  return tickets.get(id) || null
}

export function getAllTickets(): Ticket[] {
  return Array.from(tickets.values())
}

export function getUserTickets(userId: string): Ticket[] {
  return Array.from(tickets.values()).filter((t) => t.userId === userId)
}

export function updateTicket(id: string, updates: Partial<Ticket>): Ticket | null {
  const ticket = tickets.get(id)
  if (!ticket) return null

  const updated = { ...ticket, ...updates, updatedAt: new Date() }
  tickets.set(id, updated)
  return updated
}

export function deleteTicket(id: string): boolean {
  return tickets.delete(id)
}

export function addComment(ticketId: string, content: string, userId: string): Comment | null {
  const ticket = tickets.get(ticketId)
  if (!ticket) return null

  const comment: Comment = {
    id: crypto.randomUUID(),
    content,
    userId,
    createdAt: new Date(),
  }

  ticket.comments.push(comment)
  ticket.updatedAt = new Date()
  tickets.set(ticketId, ticket)
  return comment
}
