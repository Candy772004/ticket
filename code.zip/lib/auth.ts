import crypto from "crypto"

// In-memory user storage (replace with database in production)
const users: Map<string, { id: string; email: string; password: string; name: string; role: "user" | "admin" }> =
  new Map()
const sessions: Map<string, { userId: string; expiresAt: number }> = new Map()

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

export function generateSessionId(): string {
  return crypto.randomBytes(32).toString("hex")
}

export function registerUser(
  email: string,
  password: string,
  name: string,
): { id: string; email: string; name: string } | null {
  if (users.has(email)) {
    return null
  }

  const id = crypto.randomUUID()
  users.set(email, {
    id,
    email,
    password: hashPassword(password),
    name,
    role: "user",
  })

  return { id, email, name }
}

export function loginUser(email: string, password: string): string | null {
  const user = users.get(email)
  if (!user || user.password !== hashPassword(password)) {
    return null
  }

  const sessionId = generateSessionId()
  sessions.set(sessionId, {
    userId: user.id,
    expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  })

  return sessionId
}

export function validateSession(
  sessionId: string,
): { id: string; email: string; name: string; role: "user" | "admin" } | null {
  const session = sessions.get(sessionId)
  if (!session || session.expiresAt < Date.now()) {
    return null
  }

  for (const user of users.values()) {
    if (user.id === session.userId) {
      return { id: user.id, email: user.email, name: user.name, role: user.role }
    }
  }

  return null
}

export function logoutSession(sessionId: string): void {
  sessions.delete(sessionId)
}

// Helper function to get user by ID
export function getUserById(userId: string) {
  for (const user of users.values()) {
    if (user.id === userId) {
      return user
    }
  }
  return null
}

export function isUserAdmin(sessionId: string): boolean {
  const session = sessions.get(sessionId)
  if (!session || session.expiresAt < Date.now()) {
    return false
  }

  for (const user of users.values()) {
    if (user.id === session.userId && user.role === "admin") {
      return true
    }
  }

  return false
}

export function getAllUsers() {
  return Array.from(users.values()).map((u) => ({
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
  }))
}

export function updateUserRole(email: string, role: "user" | "admin"): boolean {
  const user = users.get(email)
  if (user) {
    user.role = role
    return true
  }
  return false
}

// Make first user an admin
export function makeAdmin(email: string): boolean {
  const user = users.get(email)
  if (user) {
    user.role = "admin"
    return true
  }
  return false
}
