"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertCircleIcon, CheckCircleIcon, ClockIcon, PaletteIcon as AlertIcon } from "lucide-react"

interface TicketCardProps {
  id: string
  ticketNumber: string
  title: string
  category: string
  status: "open" | "in_progress" | "waiting_for_customer" | "resolved" | "closed"
  priority: "low" | "medium" | "high" | "urgent"
  createdAt: string
  onClick?: () => void
}

export function TicketCard({
  id,
  ticketNumber,
  title,
  category,
  status,
  priority,
  createdAt,
  onClick,
}: TicketCardProps) {
  const statusConfig = {
    open: { label: "Open", color: "bg-blue-500", icon: AlertCircleIcon },
    in_progress: { label: "In Progress", color: "bg-yellow-500", icon: ClockIcon },
    waiting_for_customer: { label: "Waiting", color: "bg-orange-500", icon: AlertIcon },
    resolved: { label: "Resolved", color: "bg-green-500", icon: CheckCircleIcon },
    closed: { label: "Closed", color: "bg-gray-500", icon: CheckCircleIcon },
  }

  const priorityConfig = {
    low: "bg-blue-500/20 text-blue-300",
    medium: "bg-yellow-500/20 text-yellow-300",
    high: "bg-orange-500/20 text-orange-300",
    urgent: "bg-red-500/20 text-red-300",
  }

  const statusObj = statusConfig[status]
  const StatusIcon = statusObj.icon

  return (
    <Card onClick={onClick} className="p-4 cursor-pointer hover:bg-card-foreground/5 transition-colors">
      <div className="flex justify-between items-start mb-3">
        <div>
          <p className="text-xs text-muted-foreground">#{ticketNumber}</p>
          <h3 className="font-semibold text-card-foreground mt-1 line-clamp-2">{title}</h3>
        </div>
        <Badge className={`${statusObj.color}`}>{statusObj.label}</Badge>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded">{category}</span>
        <Badge className={priorityConfig[priority]} variant="secondary">
          {priority.charAt(0).toUpperCase() + priority.slice(1)}
        </Badge>
      </div>

      <p className="text-xs text-muted-foreground">{new Date(createdAt).toLocaleDateString()}</p>
    </Card>
  )
}
