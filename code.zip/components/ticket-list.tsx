"use client"

import type { Ticket } from "@/lib/tickets"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface TicketListProps {
  tickets: Ticket[]
}

const statusColors: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-700 dark:text-blue-300",
  "in-progress": "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300",
  resolved: "bg-green-500/20 text-green-700 dark:text-green-300",
  closed: "bg-gray-500/20 text-gray-700 dark:text-gray-300",
}

const priorityColors: Record<string, string> = {
  low: "bg-green-500/10 text-green-700 dark:text-green-300",
  medium: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  high: "bg-orange-500/10 text-orange-700 dark:text-orange-300",
  urgent: "bg-red-500/10 text-red-700 dark:text-red-300",
}

export function TicketList({ tickets }: TicketListProps) {
  if (tickets.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          No tickets yet. Create one to get started.
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {tickets.map((ticket) => (
        <Link key={ticket.id} href={`/dashboard/tickets/${ticket.id}`}>
          <Card className="hover:bg-muted/50 cursor-pointer transition-colors">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{ticket.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{ticket.description}</p>
                  <div className="flex gap-2 mt-3">
                    <Badge className={statusColors[ticket.status]}>{ticket.status}</Badge>
                    <Badge className={priorityColors[ticket.priority]}>{ticket.priority}</Badge>
                  </div>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  <p>#{ticket.id.slice(0, 8)}</p>
                  <p>{new Date(ticket.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
