"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  TicketIcon,
  SettingsIcon,
  LayoutDashboardIcon,
  LogOutIcon,
  FileTextIcon,
  UsersIcon,
  BarChart3Icon,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  userRole?: string
}

export function Sidebar({ userRole = "user" }: SidebarProps) {
  const pathname = usePathname()

  const userLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboardIcon },
    { href: "/tickets", label: "My Tickets", icon: TicketIcon },
    { href: "/tickets/new", label: "New Ticket", icon: FileTextIcon },
  ]

  const agentLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboardIcon },
    { href: "/tickets", label: "All Tickets", icon: TicketIcon },
    { href: "/dashboard/queue", label: "Ticket Queue", icon: BarChart3Icon },
  ]

  const adminLinks = [
    { href: "/admin", label: "Admin Panel", icon: LayoutDashboardIcon },
    { href: "/admin/tickets", label: "Manage Tickets", icon: TicketIcon },
    { href: "/admin/users", label: "Users", icon: UsersIcon },
    { href: "/admin/settings", label: "Settings", icon: SettingsIcon },
  ]

  const links = userRole === "admin" ? adminLinks : userRole === "support_agent" ? agentLinks : userLinks

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border h-screen fixed left-0 top-0 flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-2xl font-bold text-sidebar-primary">TicketHub</h1>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-2">
        {links.map((link) => {
          const Icon = link.icon
          const isActive = pathname === link.href
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 px-4 py-2 rounded-lg transition-colors",
                isActive
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent",
              )}
            >
              <Icon className="w-5 h-5" />
              <span>{link.label}</span>
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <button className="flex items-center gap-3 px-4 py-2 w-full text-sidebar-foreground hover:bg-sidebar-accent rounded-lg transition-colors">
          <LogOutIcon className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  )
}
