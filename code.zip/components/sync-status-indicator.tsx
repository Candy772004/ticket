"use client"

import { useState, useEffect } from "react"

export function SyncStatusIndicator() {
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSync, setLastSync] = useState<Date>(new Date())

  // Simulate sync activity
  useEffect(() => {
    const interval = setInterval(() => {
      setIsSyncing(true)
      setTimeout(() => {
        setIsSyncing(false)
        setLastSync(new Date())
      }, 500)
    }, 10000) // Sync every 10 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-2 text-xs">
      <div className={`w-2 h-2 rounded-full ${isSyncing ? "bg-yellow-500 animate-pulse" : "bg-green-500"}`} />
      <span className="text-muted-foreground">
        {isSyncing ? "Syncing..." : `Last sync: ${lastSync.toLocaleTimeString()}`}
      </span>
    </div>
  )
}
