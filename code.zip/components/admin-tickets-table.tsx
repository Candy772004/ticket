"use client"

import type { Ticket } from "@/lib/tickets"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

interface AdminTicketsTableProps {
  tickets: Ticket[]
  onStatusChange: (ticketId: string, status: string) => Promise<void>
  onAssign: (ticketId: string, adminId: string) => Promise<void>
}

const statusColors: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-700 dark:text-blue-300",
  "in-progress": "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300",
  resolved: "bg-green-500/20 text-green-700 dark:text-green-300",
  closed: "bg-gray-500/20 text-gray-700 dark:text-gray-300",
}

const priorityColors: Record<string, string> = {
  low: "bg-green-500/10 text-green-700 dark:text-green-300",
  medium: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  high: "bg-orange-500/10 text-orange-700 dark:text-orange-300",
  urgent: "bg-red-500/10 text-red-700 dark:text-red-300",
}

export function AdminTicketsTable({ tickets, onStatusChange, onAssign }: AdminTicketsTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="border-b border-border bg-muted/50">
          <tr>
            <th className="px-4 py-3 text-left font-medium">ID</th>
            <th className="px-4 py-3 text-left font-medium">Title</th>
            <th className="px-4 py-3 text-left font-medium">Status</th>
            <th className="px-4 py-3 text-left font-medium">Priority</th>
            <th className="px-4 py-3 text-left font-medium">Created</th>
            <th className="px-4 py-3 text-left font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {tickets.map((ticket) => (
            <tr key={ticket.id} className="border-b border-border hover:bg-muted/50">
              <td className="px-4 py-3 font-mono text-xs">{ticket.id.slice(0, 8)}</td>
              <td className="px-4 py-3">
                <Link href={`/admin/tickets/${ticket.id}`} className="text-primary hover:underline">
                  {ticket.title}
                </Link>
              </td>
              <td className="px-4 py-3">
                <Select value={ticket.status} onValueChange={(status) => onStatusChange(ticket.id, status)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </td>
              <td className="px-4 py-3">
                <Badge className={priorityColors[ticket.priority]}>{ticket.priority}</Badge>
              </td>
              <td className="px-4 py-3 text-xs text-muted-foreground">
                {new Date(ticket.createdAt).toLocaleDateString()}
              </td>
              <td className="px-4 py-3">
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/admin/tickets/${ticket.id}`}>View</Link>
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
