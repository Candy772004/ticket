"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Notification {
  id: string
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
  timestamp: Date
}

interface NotificationCenterProps {
  isOpen: boolean
  onClose: () => void
  notifications: Notification[]
  onClear: () => void
}

const typeColors: Record<string, string> = {
  info: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  success: "bg-green-500/10 text-green-700 dark:text-green-300",
  warning: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-300",
  error: "bg-red-500/10 text-red-700 dark:text-red-300",
}

export function NotificationCenter({ isOpen, onClose, notifications, onClear }: NotificationCenterProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <Card className="w-full m-4 max-w-md rounded-lg">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Notifications</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ✕
            </Button>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <p className="text-muted-foreground text-sm">No notifications</p>
            ) : (
              notifications.map((notif) => (
                <div key={notif.id} className="border border-border rounded p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-sm">{notif.title}</h3>
                        <Badge className={typeColors[notif.type]} variant="secondary">
                          {notif.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{notif.message}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(notif.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {notifications.length > 0 && (
            <Button variant="outline" size="sm" className="w-full mt-4 bg-transparent" onClick={onClear}>
              Clear All
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
